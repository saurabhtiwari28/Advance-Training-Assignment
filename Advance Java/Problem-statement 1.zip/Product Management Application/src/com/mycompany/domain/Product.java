package com.mycompany.domain;

public class Product {
	 String ProductID;
	 String ProductName;
     float Product_price ;
	public String getProductID() {
		return ProductID;
	}
	public void setProductID(String productID) {
		ProductID = productID;
	}
	public String getProductName() {
		return ProductName;
	}
	public void setProductName(String productName) {
		ProductName = productName;
	}
	public float getProduct_price() {
		return Product_price;
	}
	public void setProduct_price(float product_price) {
		Product_price = product_price;
	}
	
	}
     

